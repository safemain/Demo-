// Synthesises the SFX kit as 16-bit mono WAVs into public/sfx/. Deterministic, zero downloads.
// Style: soft modern UI sounds. Short, soft attack, quick decay, light low-pass + tiny reverb.
import fs from "node:fs";
import path from "node:path";
import {fileURLToPath} from "node:url";

const SR = 44100;
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");
const outDir = path.join(root, "public", "sfx");
fs.mkdirSync(outDir, {recursive: true});

// deterministic noise
let seed = 1234567;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;

const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const env = (t, a, d) => Math.min(1, t / a) * Math.exp(-t / d); // soft attack, exp decay

const lowpass = (x, hz) => {
  const a = 1 - Math.exp((-2 * Math.PI * hz) / SR);
  let y = 0;
  for (let i = 0; i < x.length; i++) x[i] = y += a * (x[i] - y);
  return x;
};
const highpass = (x, hz) => {
  const a = Math.exp((-2 * Math.PI * hz) / SR);
  let py = 0, px = 0;
  for (let i = 0; i < x.length; i++) {
    const y = a * (py + x[i] - px);
    px = x[i];
    py = y;
    x[i] = y;
  }
  return x;
};
// very small reverb: 3 damped feedback delays
const reverb = (x, wet = 0.14) => {
  const out = Float32Array.from(x);
  for (const [ms, g] of [[23, 0.34], [37, 0.26], [53, 0.2]]) {
    const d = Math.floor((ms / 1000) * SR);
    for (let i = d; i < out.length; i++) out[i] += out[i - d] * g * wet * 3;
  }
  return out;
};
const fadeEnd = (x, sec = 0.04) => {
  const n = Math.floor(sec * SR);
  for (let i = 0; i < n; i++) x[x.length - 1 - i] *= i / n;
  return x;
};

const sounds = {
  // pop: fast falling pitch sine + small envelope
  pop() {
    const x = buf(0.22);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      const f = 190 + 420 * Math.exp(-t / 0.035);
      ph += (2 * Math.PI * f) / SR;
      x[i] = Math.sin(ph) * env(t, 0.004, 0.06);
    }
    return fadeEnd(reverb(lowpass(x, 3200)));
  },
  // click: high-passed tiny noise burst + soft blip
  click() {
    const x = buf(0.1);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] = rnd() * env(t, 0.001, 0.008) * 0.8 + Math.sin(2 * Math.PI * 1900 * t) * env(t, 0.001, 0.018) * 0.5;
    }
    return fadeEnd(reverb(lowpass(highpass(x, 900), 6500), 0.08), 0.02);
  },
  // whoosh: band-pass noise sweep with fade in/out
  whoosh() {
    const x = buf(0.62);
    let low = 0, band = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR, p = t / 0.62;
      const fc = 350 + 2300 * Math.sin(Math.PI * Math.min(1, p * 0.9)) ** 1.4;
      const f = 2 * Math.sin((Math.PI * fc) / SR), q = 0.55;
      low += f * band;
      const high = rnd() - low - q * band;
      band += f * high;
      x[i] = band * Math.sin(Math.PI * p) ** 2.2;
    }
    return fadeEnd(reverb(lowpass(x, 5200), 0.1));
  },
  // chime: soft pluck with overtones
  chime() {
    const x = buf(0.62);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] =
        (Math.sin(2 * Math.PI * 784 * t) * 1 * env(t, 0.008, 0.2) +
          Math.sin(2 * Math.PI * 1175 * t) * 0.45 * env(t, 0.008, 0.13) +
          Math.sin(2 * Math.PI * 1568 * t) * 0.2 * env(t, 0.008, 0.09));
    }
    return fadeEnd(reverb(lowpass(x, 5200), 0.2), 0.08);
  },
  // thud: very soft low sine, restrained
  thud() {
    const x = buf(0.38);
    let ph = 0;
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      ph += (2 * Math.PI * (48 + 55 * Math.exp(-t / 0.05))) / SR;
      x[i] = Math.sin(ph) * env(t, 0.006, 0.11);
    }
    return fadeEnd(lowpass(x, 400), 0.06);
  },
  // tick: tiny dry tick
  tick() {
    const x = buf(0.06);
    for (let i = 0; i < x.length; i++) {
      const t = i / SR;
      x[i] = rnd() * env(t, 0.0005, 0.004) * 0.5 + Math.sin(2 * Math.PI * 2500 * t) * env(t, 0.0008, 0.01);
    }
    return fadeEnd(lowpass(highpass(x, 1200), 6000), 0.01);
  },
};

const TARGET_RMS = 0.11; // same perceived level across the kit
const PEAK_CAP = 0.85; // never clip
console.log("name     length   peak    rms");
for (const [name, make] of Object.entries(sounds)) {
  let x = make();
  let sum = 0;
  for (const v of x) sum += v * v;
  const rms = Math.sqrt(sum / x.length);
  let g = TARGET_RMS / rms;
  let peak = 0;
  for (const v of x) peak = Math.max(peak, Math.abs(v * g));
  if (peak > PEAK_CAP) g *= PEAK_CAP / peak;
  peak = 0; sum = 0;
  for (let i = 0; i < x.length; i++) {
    x[i] *= g;
    peak = Math.max(peak, Math.abs(x[i]));
    sum += x[i] * x[i];
  }
  const pcm = Buffer.alloc(44 + x.length * 2);
  pcm.write("RIFF", 0); pcm.writeUInt32LE(36 + x.length * 2, 4); pcm.write("WAVEfmt ", 8);
  pcm.writeUInt32LE(16, 16); pcm.writeUInt16LE(1, 20); pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24); pcm.writeUInt32LE(SR * 2, 28); pcm.writeUInt16LE(2, 32); pcm.writeUInt16LE(16, 34);
  pcm.write("data", 36); pcm.writeUInt32LE(x.length * 2, 40);
  for (let i = 0; i < x.length; i++) pcm.writeInt16LE(Math.round(Math.max(-1, Math.min(1, x[i])) * 32767), 44 + i * 2);
  fs.writeFileSync(path.join(outDir, `${name}.wav`), pcm);
  console.log(
    `${name.padEnd(8)} ${(x.length / SR).toFixed(2)}s   ${peak.toFixed(2)}   ${Math.sqrt(sum / x.length).toFixed(3)}${peak >= 0.99 ? "  CLIP!" : ""}`
  );
}

// Scene 1 - HOOK (Kinetic typography + logo reveal). Cue 1.
import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig, spring} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Entrance, Pill, Words, clamp} from "../components/kit";
import {MsLogo} from "../components/logos";

const Ring: React.FC<{i: number; color: string}> = ({i, color}) => {
  const f = useCurrentFrame();
  const t = ((f - 6 - i * 24 + 240) % 72) / 72; // looping idle ripple
  const show = f > 6 + i * 24 ? 1 : 0;
  return (
    <div
      style={{
        position: "absolute",
        left: 60,
        top: 60,
        width: 500,
        height: 500,
        borderRadius: "50%",
        border: `5px solid ${color}`,
        opacity: show * (1 - t) * 0.5,
        transform: `scale(${0.82 + t * 0.75})`,
      }}
    />
  );
};

export const S1Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const at = useAt();
  const p = spring({frame: frame - 2, fps, config: theme.spring.bouncy});
  const rot = interpolate(p, [0, 1], [-26, 0]);
  const breathe = 1 + Math.sin(frame / 22) * 0.015;
  const float = Math.sin(frame / 30) * 7;

  return (
    <SceneShell seed={0}>
      {/* logo block, left */}
      <div style={{position: "absolute", left: 150, top: 230, width: 620, height: 620}}>
        <Ring i={0} color={theme.colors.blue} />
        <Ring i={1} color={theme.colors.primary} />
        <Ring i={2} color={theme.colors.blue} />
        <div
          style={{
            position: "absolute",
            left: 60,
            top: 60,
            opacity: interpolate(p, [0, 0.5], [0, 1], clamp),
            transform: `translateY(${float}px) rotate(${rot}deg) scale(${(0.5 + 0.5 * p) * breathe})`,
            filter: `drop-shadow(0 0 40px ${theme.colors.glowBlue})`,
          }}
        >
          <MsLogo size={500} />
        </div>
      </div>

      {/* text block, right */}
      <AbsoluteFill style={{left: 830, justifyContent: "center", paddingRight: 90}}>
        <Words text="আসসালামু আলাইকুম" size={104} delay={at(4)} per={5} color={theme.colors.ink} />
        <div style={{height: 14}} />
        <Words
          text="আমি রাফসান"
          size={150}
          delay={at(wordFrame(1, "আমি"))}
          per={6}
          hi={["রাফসান"]}
          style={{textShadow: `0 0 50px ${theme.colors.glowRed}`}}
        />
        <div style={{height: 34}} />
        <Entrance delay={at(wordFrame(1, "এমএস"))} y={34} cfg={theme.spring.bouncy}>
          <Pill size={64} bg={theme.colors.blue} color={theme.colors.onDark} style={{boxShadow: theme.shadow.pop}}>
            এমএস চ্যালেঞ্জ
          </Pill>
        </Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};

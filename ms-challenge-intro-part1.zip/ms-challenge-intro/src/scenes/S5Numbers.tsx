// Scene 5 - THE NUMBERS (Data dashboard; only numbers that are in the script). Cues 7-8.
import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Counter, Entrance, TextPhase, Words, clamp} from "../components/kit";
import {Icon} from "../components/icons";
import {YtLogo} from "../components/logos";

const StatCard: React.FC<{
  x: number;
  delay: number;
  icon: string;
  accent: string;
  soft: string;
  kicker?: string;
  children?: React.ReactNode;
  label: string;
  sub?: string;
}> = ({x, delay, icon, accent, soft, kicker, children, label, sub}) => {
  const f = useCurrentFrame();
  const bob = Math.sin(f / 30 + x) * 4;
  return (
    <div style={{position: "absolute", left: x, top: 190, width: 740}}>
      <Entrance delay={delay} y={60} cfg={theme.spring.smooth}>
        <div
          style={{
            height: 560,
            borderRadius: theme.radius.card,
            background: theme.colors.surface,
            boxShadow: theme.shadow.card,
            transform: `translateY(${bob}px)`,
            padding: "46px 54px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
          }}
        >
          <div style={{width: 104, height: 104, borderRadius: 32, background: soft, display: "grid", placeItems: "center"}}>
            <Icon name={icon} size={56} color={accent} sw={2.1} />
          </div>
          <div style={{height: 34, marginTop: 14, fontFamily: theme.fonts.display, fontSize: 44, fontWeight: theme.weight.strong, color: theme.colors.dim, lineHeight: 1.3}}>
            {kicker}
          </div>
          <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 200, lineHeight: 1.25, color: accent, marginTop: 14}}>{children}</div>
          <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 64, lineHeight: 1.3, color: theme.colors.ink}}>{label}</div>
          {sub && <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: 40, lineHeight: 1.3, color: theme.colors.dim}}>{sub}</div>}
        </div>
      </Entrance>
    </div>
  );
};

export const S5Numbers: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const tSubs = at(wordFrame(7, "প্রায়"));
  const tViews = at(wordFrame(7, "ছয়"));
  const tNot = at(wordFrame(8, "শুধু"));
  return (
    <SceneShell seed={4}>
      <div style={{position: "absolute", left: 170, top: 46}}>
        <Entrance delay={4} y={-20} x={-30}>
          <YtLogo width={250} radius={22} style={{boxShadow: theme.shadow.soft}} />
        </Entrance>
      </div>

      <StatCard x={170} delay={tSubs} icon="person" accent={theme.colors.primary} soft={theme.colors.redSoft} kicker="প্রায়" label="subscriber">
        <Counter to={65000} delay={tSubs + 6} group minWidth={560} />
      </StatCard>
      <StatCard x={1010} delay={tViews} icon="eye" accent={theme.colors.blue} soft={theme.colors.blueSoft} kicker="একটি video-তে" label="million view">
        <Counter to={6.8} delay={tViews + 6} decimals={1} minWidth={360} />
      </StatCard>

      <TextPhase from={tNot}>
        <AbsoluteFill style={{alignItems: "center"}}>
          <div style={{position: "absolute", top: 835}}>
            <Words text="শুধু সংখ্যা নয়" size={112} align="center" hi={["নয়"]} delay={0} per={6} />
          </div>
        </AbsoluteFill>
      </TextPhase>
    </SceneShell>
  );
};

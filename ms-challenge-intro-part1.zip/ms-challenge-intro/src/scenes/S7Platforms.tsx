// Scene 7 - MORE PLATFORMS (Hub-and-spoke). Cues 10-11. Only YouTube has a real logo; others are text.
import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Entrance, TextPhase, Words, clamp, useSp} from "../components/kit";
import {YtLogo} from "../components/logos";

const HUB = {x: 960, y: 560};
const SATS = [
  {name: "Facebook", x: 330, y: 470, key: "Facebook", color: theme.colors.blue},
  {name: "TikTok", x: 1590, y: 470, key: "TikTok", color: theme.colors.ink},
  {name: "Instagram", x: 960, y: 900, key: "Instagram", color: theme.colors.primary},
];

const Spoke: React.FC<{i: number; delay: number; pulseAt: number}> = ({i, delay, pulseAt}) => {
  const f = useCurrentFrame();
  const s = SATS[i];
  const len = Math.hypot(s.x - HUB.x, s.y - HUB.y);
  const p = interpolate(f, [delay - 4, delay + 14], [0, 1], {easing: theme.ease.out, ...clamp});
  // a travelling dot hub -> satellite after cue 11 starts ("reaching more people")
  const t = f >= pulseAt ? (((f - pulseAt) * 0.022 + i * 0.33) % 1) : -1;
  return (
    <g>
      <line x1={HUB.x} y1={HUB.y} x2={s.x} y2={s.y} stroke={theme.colors.line} strokeWidth={6} strokeLinecap="round" strokeDasharray={len} strokeDashoffset={len * (1 - p)} />
      {t >= 0 && <circle cx={HUB.x + (s.x - HUB.x) * t} cy={HUB.y + (s.y - HUB.y) * t} r={13} fill={theme.colors.primary} opacity={1 - Math.abs(t - 0.5) * 0.9} />}
    </g>
  );
};

const Chip: React.FC<{i: number; delay: number}> = ({i, delay}) => {
  const f = useCurrentFrame();
  const s = SATS[i];
  const p = useSp(delay, theme.spring.bouncy);
  const bob = Math.sin(f / 26 + i * 2) * 6;
  return (
    <div
      style={{
        position: "absolute",
        left: s.x - 190,
        top: s.y - 62,
        width: 380,
        height: 124,
        opacity: interpolate(p, [0, 0.5], [0, 1], clamp),
        transform: `translateY(${bob}px) scale(${p})`,
        borderRadius: theme.radius.pill,
        background: theme.colors.surface,
        boxShadow: theme.shadow.card,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 22,
        fontFamily: theme.fonts.display,
        fontWeight: theme.weight.hero,
        fontSize: 66,
        lineHeight: 1.3,
        color: theme.colors.ink,
      }}
    >
      <span style={{width: 26, height: 26, borderRadius: "50%", background: s.color}} />
      {s.name}
    </div>
  );
};

export const S7Platforms: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const tFb = at(wordFrame(10, "Facebook"));
  const tTt = at(wordFrame(10, "TikTok"));
  const tIg = at(wordFrame(10, "Instagram"));
  const tMore = at(wordFrame(11, "আরও"));
  const hubP = useSp(5, theme.spring.bouncy);
  const ring = (k: number) => ((f - tMore - k * 20) % 60) / 60;

  return (
    <SceneShell seed={6}>
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        {f >= tMore &&
          [0, 1, 2].map((k) => {
            const t = ring(k);
            return f - tMore - k * 20 < 0 ? null : (
              <circle key={k} cx={HUB.x} cy={HUB.y} r={120 + t * 520} fill="none" stroke={theme.colors.blue} strokeWidth={4} opacity={(1 - t) * 0.35} />
            );
          })}
        <Spoke i={0} delay={tFb} pulseAt={tMore} />
        <Spoke i={1} delay={tTt} pulseAt={tMore} />
        <Spoke i={2} delay={tIg} pulseAt={tMore} />
      </svg>

      <div
        style={{
          position: "absolute",
          left: HUB.x - 330,
          top: HUB.y - 105,
          opacity: interpolate(hubP, [0, 0.5], [0, 1], clamp),
          transform: `scale(${0.6 + 0.4 * hubP}) translateY(${Math.sin(f / 30) * 4}px)`,
          filter: `drop-shadow(0 0 30px ${theme.colors.glowRed})`,
        }}
      >
        <YtLogo width={660} radius={40} />
      </div>

      <Chip i={0} delay={tFb} />
      <Chip i={1} delay={tTt} />
      <Chip i={2} delay={tIg} />

      <AbsoluteFill style={{alignItems: "center"}}>
        <TextPhase from={at(2)} to={tMore - 4}>
          <AbsoluteFill style={{alignItems: "center"}}>
            <div style={{position: "absolute", top: 70}}>
              <Words text="শুধু YouTube নয়" size={104} align="center" hi={["নয়"]} delay={0} per={6} />
            </div>
          </AbsoluteFill>
        </TextPhase>
        <TextPhase from={tMore - 2}>
          <AbsoluteFill style={{alignItems: "center"}}>
            <div style={{position: "absolute", top: 70}}>
              <Words text="আরও বেশি মানুষের কাছে" size={96} align="center" hi={["আরও"]} delay={0} per={5} />
            </div>
          </AbsoluteFill>
        </TextPhase>
      </AbsoluteFill>
    </SceneShell>
  );
};

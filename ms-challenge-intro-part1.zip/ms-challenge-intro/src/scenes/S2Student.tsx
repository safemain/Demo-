// Scene 2 - STUDENT (Timeline / process flow). Cues 2-3.
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Entrance, Pill, Words, clamp, useSp} from "../components/kit";
import {Icon} from "../components/icons";

const Node: React.FC<{x: number; delay: number; done?: boolean; title: string; sub: string}> = ({x, delay, done, title, sub}) => {
  const f = useCurrentFrame();
  const p = useSp(delay, theme.spring.bouncy);
  const pulse = done ? 0 : ((f - delay) % 60) / 60;
  const tick = interpolate(f, [delay + 8, delay + 20], [0, 1], {easing: theme.ease.out, ...clamp});
  return (
    <div style={{position: "absolute", left: x - 260, top: 600, width: 520, textAlign: "center"}}>
      <div style={{opacity: interpolate(p, [0, 0.5], [0, 1], clamp), transform: `scale(${p})`}}>
        <div style={{position: "relative", width: 112, height: 112, margin: "0 auto"}}>
          {!done && f > delay && (
            <div
              style={{
                position: "absolute",
                inset: 0,
                borderRadius: "50%",
                border: `5px solid ${theme.colors.primary}`,
                opacity: 0.55 * (1 - pulse),
                transform: `scale(${1 + pulse * 0.7})`,
              }}
            />
          )}
          <div
            style={{
              width: 112,
              height: 112,
              borderRadius: "50%",
              background: done ? theme.colors.blue : theme.colors.primary,
              boxShadow: done ? theme.shadow.pop : `0 24px 50px -18px ${theme.colors.glowRed}`,
              display: "grid",
              placeItems: "center",
            }}
          >
            <Icon name={done ? "check" : "star"} size={58} color={theme.colors.onDark} sw={2.6} draw={done ? tick : undefined} />
          </div>
        </div>
      </div>
      <Entrance delay={delay + 6} y={22}>
        <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 60, lineHeight: 1.3, color: theme.colors.ink, marginTop: 18}}>
          {title}
        </div>
        <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: 40, lineHeight: 1.3, color: theme.colors.dim}}>{sub}</div>
      </Entrance>
    </div>
  );
};

const StepCard: React.FC<{x: number; delay: number; icon: string; label: string; tint: string; fg: string}> = ({x, delay, icon, label, tint, fg}) => (
  <div style={{position: "absolute", left: x, top: 0}}>
    <Entrance delay={delay} y={44} cfg={theme.spring.snappy}>
      <div
        style={{
          width: 400,
          height: 170,
          borderRadius: theme.radius.card,
          background: theme.colors.surface,
          boxShadow: theme.shadow.card,
          display: "flex",
          alignItems: "center",
          gap: 26,
          padding: "0 34px",
        }}
      >
        <div style={{width: 92, height: 92, borderRadius: 28, background: tint, display: "grid", placeItems: "center", flex: "none"}}>
          <Icon name={icon} size={50} color={fg} sw={2.2} />
        </div>
        <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 56, lineHeight: 1.3, color: theme.colors.ink}}>{label}</div>
      </div>
    </Entrance>
  </div>
);

export const S2Student: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const moveAt = at(wordFrame(3, "পড়াশোনার")) - 6;
  const m = interpolate(f, [moveAt, moveAt + 22], [0, 1], {easing: theme.ease.inOut, ...clamp});
  const lineP = interpolate(f, [at(wordFrame(2, "প্রথম")), at(wordFrame(2, "দ্বিতীয়"))], [0, 1], {easing: theme.ease.inOut, ...clamp});

  return (
    <SceneShell seed={1}>
      {/* group A: headline + timeline; shrinks upward when cue 3 starts */}
      <div
        style={{
          position: "absolute",
          left: 0,
          top: 110,
          width: 1920,
          height: 860,
          transformOrigin: "50% 0%",
          transform: `translateY(${-30 * m}px) scale(${1 - 0.3 * m})`,
        }}
      >
        <div style={{position: "absolute", left: 0, right: 0, top: 0, display: "flex", flexDirection: "column", alignItems: "center"}}>
          <Words text="বর্তমানে আমি" size={60} delay={at(3)} color={theme.colors.dim} weight={theme.weight.strong} align="center" />
          <Words text="একজন student" size={160} delay={at(8)} per={6} hi={["student"]} align="center" />
          <Entrance delay={at(wordFrame(2, "Intermediate"))} y={26} cfg={theme.spring.bouncy} style={{marginTop: 26}}>
            <Pill size={50} bg={theme.colors.blue} color={theme.colors.onDark} style={{boxShadow: theme.shadow.pop}}>
              Intermediate
            </Pill>
          </Entrance>
        </div>
        {/* timeline rail */}
        <div style={{position: "absolute", left: 560, width: 800, top: 653, height: 8, borderRadius: 8, background: theme.colors.line}} />
        <div
          style={{
            position: "absolute",
            left: 560,
            width: 800 * lineP,
            top: 653,
            height: 8,
            borderRadius: 8,
            background: `linear-gradient(90deg, ${theme.colors.blue}, ${theme.colors.primary})`,
          }}
        />
        <Node x={560} delay={at(wordFrame(2, "প্রথম"))} done title="প্রথম বর্ষ" sub="শেষ" />
        <Node x={1360} delay={at(wordFrame(2, "দ্বিতীয়"))} title="দ্বিতীয় বর্ষ" sub="সবেমাত্র উঠেছি" />
      </div>

      {/* group B: study + work -> dream (cue 3) */}
      <div style={{position: "absolute", left: 0, top: 770, width: 1920, height: 200}}>
        <StepCard x={260} delay={at(wordFrame(3, "পড়াশোনার"))} icon="book" label="পড়াশোনা" tint={theme.colors.blueSoft} fg={theme.colors.blue} />
        <div style={{position: "absolute", left: 686, top: 52}}>
          <Entrance delay={at(wordFrame(3, "পড়াশোনার")) + 5} y={0} from={0.4}>
            <Icon name="plus" size={66} color={theme.colors.dim} sw={2.6} />
          </Entrance>
        </div>
        <StepCard x={780} delay={at(wordFrame(3, "কাজ"))} icon="bolt" label="কাজ" tint={theme.colors.blueSoft} fg={theme.colors.blue} />
        <div style={{position: "absolute", left: 1206, top: 52}}>
          <Entrance delay={at(wordFrame(3, "কাজ")) + 5} x={-20} y={0} from={0.6}>
            <Icon name="arrow" size={66} color={theme.colors.dim} sw={2.6} />
          </Entrance>
        </div>
        <StepCard x={1300} delay={at(wordFrame(3, "স্বপ্ন"))} icon="star" label="স্বপ্ন পূরণ" tint={theme.colors.redSoft} fg={theme.colors.primary} />
      </div>
    </SceneShell>
  );
};

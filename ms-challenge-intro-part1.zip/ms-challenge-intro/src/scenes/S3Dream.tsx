// Scene 3 - THE DREAM (line-draw globe: Bangladesh -> international). Cues 4-5.
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Words, TextPhase, clamp, useSp} from "../components/kit";
import {MsLogo} from "../components/logos";

const CX = 1380;
const CY = 560;
const R = 300;
const PIN = {x: CX + 40, y: CY + 40}; // home pin
const TARGETS = [
  {x: CX - 170, y: CY - 130},
  {x: CX - 120, y: CY + 175},
  {x: CX + 200, y: CY - 150},
];

const draw = (f: number, start: number, len: number, total: number) =>
  total * (1 - interpolate(f, [start, start + len], [0, 1], {easing: theme.ease.inOut, ...clamp}));

const Target: React.FC<{i: number; delay: number}> = ({i, delay}) => {
  const f = useCurrentFrame();
  const t = TARGETS[i];
  const p = useSp(delay + i * 5, theme.spring.bouncy);
  const mx = (PIN.x + t.x) / 2;
  const my = Math.min(PIN.y, t.y) - 90;
  const d = `M ${PIN.x} ${PIN.y} Q ${mx} ${my} ${t.x} ${t.y}`;
  return (
    <g>
      <path d={d} fill="none" stroke={theme.colors.blue} strokeWidth={5} strokeLinecap="round" strokeDasharray="1000" strokeDashoffset={draw(f, delay + i * 5, 22, 1000)} />
      <circle cx={t.x} cy={t.y} r={20 * p} fill={theme.colors.blue} />
      <circle cx={t.x} cy={t.y} r={(20 + 16 * ((f % 50) / 50)) * p} fill="none" stroke={theme.colors.blue} strokeWidth={3} opacity={(1 - (f % 50) / 50) * 0.6 * p} />
    </g>
  );
};

export const S3Dream: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const tBound = at(wordFrame(4, "গণ্ডি"));
  const tCross = at(wordFrame(4, "পেরিয়ে"));
  const tIntl = at(wordFrame(4, "আন্তর্জাতিক"));
  const tIdentity = at(wordFrame(4, "নিজের")); // "নিজের" closes cue 4; "পরিচয়" opens cue 5
  const tLogo = at(wordFrame(5, "এমএস"));
  const tHeight = at(wordFrame(5, "এমন"));

  const globeIn = interpolate(f, [4, 40], [0, 1], {easing: theme.ease.out, ...clamp});
  const spin = Math.sin(f / 40) * 0.0; // keep globe still, calm
  const logoP = useSp(tLogo, theme.spring.bouncy);
  const rise = interpolate(f, [tHeight, tHeight + 50], [0, -60], {easing: theme.ease.inOut, ...clamp});
  const float = Math.sin(f / 26) * 6;

  // dashed "boundary" around the home pin, breaks open at "পেরিয়ে"
  const bScale = interpolate(f, [tBound, tBound + 14], [0.2, 1], {easing: theme.ease.out, ...clamp});
  const bBreak = interpolate(f, [tCross, tCross + 16], [0, 1], {easing: theme.ease.out, ...clamp});

  return (
    <SceneShell seed={2}>
      <svg width={1920} height={1080} style={{position: "absolute", inset: 0}}>
        <g opacity={globeIn} transform={`rotate(${spin} ${CX} ${CY})`}>
          <circle cx={CX} cy={CY} r={R} fill={theme.colors.surface} opacity={0.75} />
          <circle cx={CX} cy={CY} r={R} fill="none" stroke={theme.colors.blue} strokeWidth={7} strokeDasharray="2000" strokeDashoffset={draw(f, 4, 38, 2000)} />
          {[0.35, 0.7].map((k, i) => (
            <ellipse key={i} cx={CX} cy={CY} rx={R * k} ry={R} fill="none" stroke={theme.colors.blue} strokeOpacity={0.35} strokeWidth={3} strokeDasharray="2000" strokeDashoffset={draw(f, 14 + i * 5, 36, 2000)} />
          ))}
          <ellipse cx={CX} cy={CY} rx={R} ry={R * 0.3} fill="none" stroke={theme.colors.blue} strokeOpacity={0.35} strokeWidth={3} strokeDasharray="2000" strokeDashoffset={draw(f, 24, 36, 2000)} />
          {[-0.5, 0.5].map((k, i) => {
            const d = R * k;
            const w = Math.sqrt(R * R - d * d);
            return <line key={i} x1={CX - w} x2={CX + w} y1={CY + d} y2={CY + d} stroke={theme.colors.blue} strokeOpacity={0.3} strokeWidth={3} strokeDasharray="700" strokeDashoffset={draw(f, 30 + i * 5, 30, 700)} />;
          })}
        </g>

        {/* home pin: Bangladesh */}
        <g>
          <circle cx={PIN.x} cy={PIN.y} r={16 * useSp(at(10), theme.spring.bouncy)} fill={theme.colors.primary} />
          <circle cx={PIN.x} cy={PIN.y} r={16 + 26 * ((f % 60) / 60)} fill="none" stroke={theme.colors.primary} strokeWidth={3} opacity={(1 - (f % 60) / 60) * 0.7} />
          {f >= tBound && (
            <circle
              cx={PIN.x}
              cy={PIN.y}
              r={92 * bScale + bBreak * 70}
              fill="none"
              stroke={theme.colors.primary}
              strokeWidth={5}
              strokeDasharray="18 14"
              strokeDashoffset={-f * 1.2}
              opacity={1 - bBreak}
            />
          )}
        </g>
        {f >= tCross && TARGETS.map((_, i) => <Target key={i} i={i} delay={tCross} />)}
      </svg>

      {/* MS logo rises toward "an altitude" (cue 5) */}
      <div
        style={{
          position: "absolute",
          left: CX + 80,
          top: 120,
          opacity: interpolate(logoP, [0, 0.5], [0, 1], clamp),
          transform: `translateY(${rise + float}px) scale(${logoP})`,
          filter: `drop-shadow(0 0 30px ${theme.colors.glowBlue})`,
        }}
      >
        <MsLogo size={230} />
      </div>

      {/* text column, left - changes with the sentence */}
      <div style={{position: "absolute", left: 120, top: 0, width: 880, height: 1080}}>
        <TextPhase from={at(4)} to={tBound - 6}>
          <div style={{position: "absolute", left: 0, top: 330}}>
            <Words text="আমার স্বপ্ন" size={72} color={theme.colors.dim} weight={theme.weight.strong} delay={0} />
            <Words text="একটু বড়" size={190} hi={["বড়"]} delay={6} per={7} />
          </div>
        </TextPhase>
        <TextPhase from={tBound - 2} to={tIntl - 4}>
          <div style={{position: "absolute", left: 0, top: 360}}>
            <Words text="বাংলাদেশের" size={110} delay={0} />
            <Words text="গণ্ডি পেরিয়ে" size={150} hi={["পেরিয়ে"]} delay={6} />
          </div>
        </TextPhase>
        <TextPhase from={tIntl - 2} to={tIdentity - 4}>
          <div style={{position: "absolute", left: 0, top: 360}}>
            <Words text="আন্তর্জাতিক" size={150} hi={["আন্তর্জাতিক"]} delay={0} />
            <Words text="পর্যায়ে" size={150} delay={6} />
          </div>
        </TextPhase>
        <TextPhase from={tIdentity - 2} to={tHeight - 4}>
          <div style={{position: "absolute", left: 0, top: 360}}>
            <Words text="নিজের" size={96} color={theme.colors.dim} weight={theme.weight.strong} delay={0} />
            <Words text="পরিচয়" size={160} hi={["পরিচয়"]} delay={5} />
          </div>
        </TextPhase>
        <TextPhase from={tHeight - 2}>
          <div style={{position: "absolute", left: 0, top: 330}}>
            <Words text="এমন এক" size={96} color={theme.colors.dim} weight={theme.weight.strong} delay={0} />
            <Words text="উচ্চতায়" size={190} hi={["উচ্চতায়"]} delay={6} />
          </div>
        </TextPhase>
      </div>
    </SceneShell>
  );
};

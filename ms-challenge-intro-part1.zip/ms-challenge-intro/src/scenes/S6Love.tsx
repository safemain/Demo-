// Scene 6 - LOVE / TRUST / EFFORT (Glass cards). Cue 9.
import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Entrance, Pill} from "../components/kit";
import {Icon} from "../components/icons";

const GlassCard: React.FC<{x: number; delay: number; icon: string; title: string; sub: string; accent: string; soft: string}> = ({
  x,
  delay,
  icon,
  title,
  sub,
  accent,
  soft,
}) => {
  const f = useCurrentFrame();
  const bob = Math.sin(f / 28 + x / 300) * 5;
  const sheen = interpolate(f, [delay + 10, delay + 40], [-60, 160], {easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp"});
  return (
    <div style={{position: "absolute", left: x, top: 210, width: 500}}>
      <Entrance delay={delay} y={70} cfg={theme.spring.smooth}>
        <div
          style={{
            position: "relative",
            height: 520,
            borderRadius: theme.radius.card,
            background: "linear-gradient(160deg, rgba(255,255,255,0.96), rgba(255,255,255,0.7))",
            border: "2px solid rgba(255,255,255,0.9)",
            boxShadow: theme.shadow.card,
            transform: `translateY(${bob}px)`,
            overflow: "hidden",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <div
            style={{
              position: "absolute",
              top: -40,
              bottom: -40,
              width: 120,
              left: `${sheen}%`,
              background: "linear-gradient(90deg, transparent, rgba(255,255,255,0.8), transparent)",
              transform: "skewX(-16deg)",
            }}
          />
          <div style={{width: 168, height: 168, borderRadius: 52, background: soft, display: "grid", placeItems: "center", marginBottom: 18}}>
            <Icon name={icon} size={92} color={accent} sw={1.9} />
          </div>
          <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.body, fontSize: 44, lineHeight: 1.3, color: theme.colors.dim}}>{sub}</div>
          <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 92, lineHeight: 1.3, color: theme.colors.ink}}>{title}</div>
        </div>
      </Entrance>
    </div>
  );
};

export const S6Love: React.FC = () => {
  const at = useAt();
  return (
    <SceneShell seed={5}>
      <GlassCard x={150} delay={at(wordFrame(9, "ভালোবাসা"))} icon="heart" title="ভালোবাসা" sub="আপনাদের" accent={theme.colors.primary} soft={theme.colors.redSoft} />
      <GlassCard x={710} delay={at(wordFrame(9, "বিশ্বাস"))} icon="shield" title="বিশ্বাস" sub="আপনাদের" accent={theme.colors.blue} soft={theme.colors.blueSoft} />
      <GlassCard x={1270} delay={at(wordFrame(9, "অক্লান্ত"))} icon="bolt" title="পরিশ্রম" sub="আমাদের অক্লান্ত" accent={theme.colors.blue} soft={theme.colors.blueSoft} />
      <AbsoluteFill style={{alignItems: "center"}}>
        <div style={{position: "absolute", top: 860}}>
          <Entrance delay={at(wordFrame(9, "প্রতিচ্ছবি"))} y={30} cfg={theme.spring.bouncy}>
            <Pill size={64} bg={theme.colors.ink} color={theme.colors.onDark}>
              সবকিছুর প্রতিচ্ছবি
            </Pill>
          </Entrance>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};

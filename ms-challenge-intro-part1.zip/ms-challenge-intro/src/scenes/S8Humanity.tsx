// Scene 8 - MORE THAN A BIG YOUTUBER (Checklist / recap). Cues 12-13.
import React from "react";
import {interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Entrance, Strike, Words, clamp} from "../components/kit";
import {Icon} from "../components/icons";

const Row: React.FC<{y: number; delay: number; icon: string; text: string}> = ({y, delay, icon, text}) => {
  const f = useCurrentFrame();
  const tick = interpolate(f, [delay + 6, delay + 18], [0, 1], {easing: theme.ease.out, ...clamp});
  return (
    <div style={{position: "absolute", left: 960, top: y, width: 860}}>
      <Entrance delay={delay} x={80} y={0} from={0.96} cfg={theme.spring.snappy}>
        <div
          style={{
            height: 190,
            borderRadius: theme.radius.card,
            background: theme.colors.surface,
            boxShadow: theme.shadow.card,
            display: "flex",
            alignItems: "center",
            gap: 30,
            padding: "0 38px",
          }}
        >
          <div style={{width: 96, height: 96, borderRadius: "50%", background: theme.colors.blue, display: "grid", placeItems: "center", flex: "none", boxShadow: theme.shadow.pop}}>
            <Icon name="check" size={52} color={theme.colors.onDark} sw={2.8} draw={tick} />
          </div>
          <div style={{flex: 1, fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 52, lineHeight: 1.3, color: theme.colors.ink}}>{text}</div>
          <div style={{flex: "none", opacity: 0.9}}>
            <Icon name={icon} size={60} color={theme.colors.primary} sw={1.9} />
          </div>
        </div>
      </Entrance>
    </div>
  );
};

export const S8Humanity: React.FC = () => {
  const at = useAt();
  const tNo = at(wordFrame(12, "নয়"));
  return (
    <SceneShell seed={7}>
      {/* left: the statement; the "big YouTuber" goal gets struck through */}
      <div style={{position: "absolute", left: 120, top: 250, width: 800}}>
        <Words text="আমাদের স্বপ্ন শুধু" size={64} color={theme.colors.dim} weight={theme.weight.strong} delay={at(3)} />
        <div style={{display: "flex", flexDirection: "column", alignItems: "flex-start", marginTop: 10}}>
          <Entrance delay={at(8)} y={34}>
            <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 118, lineHeight: 1.3, color: theme.colors.ink}}>
              <Strike delay={tNo}>
                <span style={{opacity: 0.75}}>বড় YouTuber</span>
              </Strike>
            </div>
          </Entrance>
          <Entrance delay={at(13)} y={34}>
            <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.hero, fontSize: 118, lineHeight: 1.3, color: theme.colors.ink}}>
              <Strike delay={tNo}>
                <span style={{opacity: 0.75}}>হওয়া</span>
              </Strike>{" "}
              <span style={{color: theme.colors.primary, textShadow: `0 0 40px ${theme.colors.glowRed}`}}>নয়</span>
            </div>
          </Entrance>
        </div>
      </div>

      {/* right: what we want to do instead */}
      <Row y={150} delay={at(wordFrame(12, "মুখে"))} icon="smile" text="মানুষের মুখে হাসি ফোটাতে" />
      <Row y={380} delay={at(wordFrame(13, "পাশে"))} icon="users" text="মানুষের পাশে দাঁড়াতে" />
      <Row y={610} delay={at(wordFrame(13, "মানবতার"))} icon="heart" text="মানবতার জন্য কিছু করতে" />
    </SceneShell>
  );
};

// Scene 4 - THE WORLD WATCHES -> YouTube channel (Statement card). Cue 6.
import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Entrance, Words, TextPhase, clamp, useSp} from "../components/kit";
import {Icon} from "../components/icons";
import {YtLogo} from "../components/logos";

const Tile: React.FC<{i: number; delay: number}> = ({i, delay}) => {
  const f = useCurrentFrame();
  const p = useSp(delay + i * 5, theme.spring.snappy);
  const blue = i % 2 === 0;
  const bob = Math.sin(f / 24 + i * 1.3) * 6;
  return (
    <div
      style={{
        width: 250,
        height: 150,
        borderRadius: theme.radius.tile,
        background: blue ? theme.colors.blueSoft : theme.colors.redSoft,
        boxShadow: theme.shadow.soft,
        display: "grid",
        placeItems: "center",
        opacity: interpolate(p, [0, 0.6], [0, 1], clamp),
        transform: `translateY(${(1 - p) * 50 + bob}px) scale(${0.85 + 0.15 * p})`,
      }}
    >
      <div
        style={{
          width: 70,
          height: 70,
          borderRadius: "50%",
          background: blue ? theme.colors.blue : theme.colors.primary,
          display: "grid",
          placeItems: "center",
          paddingLeft: 5,
        }}
      >
        <Icon name="play" size={34} color={theme.colors.onDark} />
      </div>
    </div>
  );
};

export const S4World: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const tYt = at(wordFrame(6, "আলহামদুলিল্লাহ"));
  const logoP = useSp(at(wordFrame(6, "YouTube")), theme.spring.bouncy);
  const glow = 0.5 + 0.5 * Math.sin(f / 18);

  return (
    <SceneShell seed={3}>
      <TextPhase from={at(2)} to={tYt - 2}>
        <AbsoluteFill style={{alignItems: "center"}}>
          <div style={{marginTop: 150, display: "flex", flexDirection: "column", alignItems: "center"}}>
            <Words text="আমাদের video দেখবে" size={74} color={theme.colors.dim} weight={theme.weight.strong} align="center" delay={0} />
            <Words text="পুরো পৃথিবীর মানুষ" size={150} hi={["পৃথিবীর"]} align="center" delay={7} per={6} />
          </div>
          <div style={{position: "absolute", top: 690, left: 120, display: "flex", gap: 36}}>
            {[0, 1, 2, 3, 4, 5].map((i) => (
              <Tile key={i} i={i} delay={14} />
            ))}
          </div>
        </AbsoluteFill>
      </TextPhase>

      <TextPhase from={tYt}>
        <AbsoluteFill style={{alignItems: "center", justifyContent: "center"}}>
          <Words text="আলহামদুলিল্লাহ" size={86} color={theme.colors.dim} weight={theme.weight.strong} align="center" delay={0} style={{marginBottom: 24}} />
          <div
            style={{
              opacity: interpolate(logoP, [0, 0.5], [0, 1], clamp),
              transform: `scale(${0.7 + 0.3 * logoP}) translateY(${Math.sin(f / 26) * 5}px)`,
              filter: `drop-shadow(0 0 ${28 + glow * 20}px ${theme.colors.glowRed})`,
            }}
          >
            <YtLogo width={880} radius={44} />
          </div>
          <Entrance delay={at(wordFrame(6, "YouTube")) + 8} y={24}>
            <div style={{fontFamily: theme.fonts.display, fontWeight: theme.weight.strong, fontSize: 64, lineHeight: 1.3, color: theme.colors.ink, marginTop: 28}}>আমাদের channel</div>
          </Entrance>
        </AbsoluteFill>
      </TextPhase>
    </SceneShell>
  );
};

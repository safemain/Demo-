// Scene 9 - OUR BIGGEST STRENGTH (Statement + logo). Cue 14. Last scene of Part 1: no exit, holds clean.
import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {wordFrame} from "../timing";
import {useAt} from "../components/ctx";
import {SceneShell} from "../components/layers";
import {Words, clamp, useSp} from "../components/kit";
import {MsLogo} from "../components/logos";

const Burst: React.FC<{delay: number}> = ({delay}) => {
  const f = useCurrentFrame();
  const rays = 14;
  return (
    <>
      {Array.from({length: rays}).map((_, i) => {
        const t = interpolate(f, [delay + i * 1.2, delay + i * 1.2 + 22], [0, 1], {easing: theme.ease.out, ...clamp});
        const a = (360 / rays) * i;
        return (
          <div
            key={i}
            style={{
              position: "absolute",
              left: "50%",
              top: "50%",
              width: 10,
              height: 60 * t,
              borderRadius: 10,
              background: i % 2 ? theme.colors.blue : theme.colors.primary,
              opacity: (1 - Math.max(0, (t - 0.6) / 0.4)) * 0.85,
              transformOrigin: "50% 0%",
              transform: `translateX(-50%) rotate(${a}deg) translateY(${250 + t * 40}px)`,
            }}
          />
        );
      })}
    </>
  );
};

export const S9Strength: React.FC = () => {
  const f = useCurrentFrame();
  const at = useAt();
  const logoP = useSp(4, theme.spring.bouncy);
  const tBig = at(wordFrame(14, "সবচেয়ে"));
  const tLine = at(wordFrame(14, "আমাদের"));
  const breathe = 1 + Math.sin(f / 22) * 0.015;
  const glow = 0.6 + 0.4 * Math.sin(f / 16);
  return (
    <SceneShell seed={8}>
      <div style={{position: "absolute", left: 960 - 220, top: 90, width: 440, height: 440}}>
        <Burst delay={tBig - 4} />
        <div
          style={{
            opacity: interpolate(logoP, [0, 0.5], [0, 1], clamp),
            transform: `scale(${logoP * breathe})`,
            filter: `drop-shadow(0 0 ${30 + glow * 24}px ${theme.colors.glowBlue})`,
          }}
        >
          <MsLogo size={440} />
        </div>
      </div>
      <AbsoluteFill style={{alignItems: "center", justifyContent: "flex-end", paddingBottom: 110}}>
        <Words text="আপনাদের ভালোবাসা এবং support" size={78} color={theme.colors.dim} weight={theme.weight.strong} align="center" delay={at(3)} per={4} />
        <Words
          text="আমাদের সবচেয়ে বড় শক্তি"
          size={132}
          align="center"
          hi={["বড়", "শক্তি"]}
          delay={tLine}
          per={5}
          style={{textShadow: `0 0 50px ${theme.colors.glowRed}`}}
        />
      </AbsoluteFill>
    </SceneShell>
  );
};

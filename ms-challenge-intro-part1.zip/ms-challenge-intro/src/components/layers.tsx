import React from "react";
import {AbsoluteFill, interpolate, useCurrentFrame} from "remotion";
import {theme} from "../theme";
import {clamp} from "./kit";
import {useScene} from "./ctx";

/** Layer 1 - animated background mesh (never a flat colour). `seed` varies blob placement per scene. */
export const BgMesh: React.FC<{seed?: number}> = ({seed = 0}) => {
  const frame = useCurrentFrame();
  const flip = seed % 2 === 0 ? 1 : -1;
  const d1 = Math.sin(frame / 55 + seed) * 50;
  const d2 = Math.cos(frame / 70 + seed) * 40;
  return (
    <AbsoluteFill style={{background: theme.colors.bg}}>
      <div
        style={{
          position: "absolute",
          width: 1100,
          height: 1100,
          borderRadius: "50%",
          top: -420 + (seed % 3) * 60,
          left: flip > 0 ? -260 + d1 : 1100 - d1,
          filter: "blur(60px)",
          background: `radial-gradient(circle, ${theme.colors.blue}38, transparent 64%)`,
        }}
      />
      <div
        style={{
          position: "absolute",
          width: 900,
          height: 900,
          borderRadius: "50%",
          bottom: -380,
          right: flip > 0 ? -220 - d2 : 1000 + d2,
          filter: "blur(70px)",
          background: `radial-gradient(circle, ${theme.colors.primary}26, transparent 66%)`,
        }}
      />
      <AbsoluteFill
        style={{
          backgroundImage: `radial-gradient(${theme.colors.ink}14 1.6px, transparent 1.8px)`,
          backgroundSize: "56px 56px",
          backgroundPosition: `${(frame * 0.25) % 56}px 0px`,
          maskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)",
          WebkitMaskImage: "radial-gradient(ellipse at center, black 30%, transparent 78%)",
        }}
      />
    </AbsoluteFill>
  );
};

/** Wraps a scene: background + content with a fast exit (faster than the entrances). */
export const SceneShell: React.FC<{seed?: number; children?: React.ReactNode}> = ({seed = 0, children}) => {
  const frame = useCurrentFrame();
  const {dur, last} = useScene();
  const x = last
    ? 0
    : interpolate(frame, [dur - theme.motion.exitFrames, dur - 1], [0, 1], {easing: theme.ease.in, ...clamp});
  return (
    <AbsoluteFill>
      <BgMesh seed={seed} />
      <AbsoluteFill style={{opacity: 1 - x, transform: `translateY(${-36 * x}px) scale(${1 + 0.03 * x})`}}>
        {children}
      </AbsoluteFill>
    </AbsoluteFill>
  );
};

/** Layer 4 - colour grade, unifies logos + graphics. */
export const Grade: React.FC = () => (
  <AbsoluteFill style={{pointerEvents: "none"}}>
    <AbsoluteFill style={{backgroundColor: theme.colors.blue, mixBlendMode: "soft-light", opacity: 0.1}} />
    <AbsoluteFill
      style={{background: "linear-gradient(180deg, rgba(255,255,255,0.18), transparent 22%, transparent 78%, rgba(16,19,31,0.06))"}}
    />
  </AbsoluteFill>
);

const NOISE = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;

/** Layer 5a - procedural film grain (no asset file). */
export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  return (
    <AbsoluteFill
      style={{
        pointerEvents: "none",
        backgroundImage: NOISE,
        backgroundSize: "220px",
        backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`,
        opacity: 0.05,
        mixBlendMode: "multiply",
      }}
    />
  );
};

/** Layer 5b - vignette, topmost. */
export const Vignette: React.FC = () => (
  <AbsoluteFill
    style={{pointerEvents: "none", background: "radial-gradient(ellipse at center, transparent 58%, rgba(16,19,31,0.12) 100%)"}}
  />
);

/**
 * Scene-to-scene transition: two skewed colour panels sweep in, HOLD fully covering the frame for a
 * few frames (the scene cut happens here, theme.motion.wipeCutAt frames in), then sweep out.
 */
export const Wipe: React.FC = () => {
  const f = useCurrentFrame();
  const panel = (d: number, color: string) => {
    const inP = interpolate(f, [d, d + 7], [0, 0.5], {easing: theme.ease.out, ...clamp});
    const outP = interpolate(f, [d + 11, d + 18], [0.5, 1], {easing: theme.ease.in, ...clamp});
    const p = f < d + 11 ? inP : outP;
    return (
      <div
        style={{
          position: "absolute",
          top: -120,
          bottom: -120,
          left: "-20%",
          width: "150%",
          background: color,
          transform: `translateX(${-140 + p * 280}%) skewX(-14deg)`,
        }}
      />
    );
  };
  return (
    <AbsoluteFill style={{pointerEvents: "none", overflow: "hidden"}}>
      {panel(0, theme.colors.blue)}
      {panel(3, theme.colors.primary)}
    </AbsoluteFill>
  );
};

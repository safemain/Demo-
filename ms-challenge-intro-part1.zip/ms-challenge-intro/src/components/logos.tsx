import React, {CSSProperties} from "react";
import {Img, staticFile} from "remotion";
import {theme} from "../theme";

/** Official YouTube logo, used exactly as supplied (cropped only; same aspect ratio 1226x384). */
export const YtLogo: React.FC<{width: number; radius?: number; style?: CSSProperties}> = ({
  width,
  radius = theme.radius.card,
  style,
}) => (
  <Img
    src={staticFile("logos/youtube.png")}
    style={{
      width,
      height: Math.round((width * 384) / 1226),
      display: "block",
      borderRadius: radius,
      boxShadow: theme.shadow.card,
      ...style,
    }}
  />
);

/** MS Challenge channel logo, used exactly as supplied (500x500, transparent). */
export const MsLogo: React.FC<{size: number; style?: CSSProperties}> = ({size, style}) => (
  <Img src={staticFile("logos/ms-challenge.png")} style={{width: size, height: size, display: "block", ...style}} />
);

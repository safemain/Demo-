import React from "react";

// Hand-built stroke icons (no emoji, so colours always follow the theme).
const P: Record<string, React.ReactNode> = {
  check: <path d="M5 13l4.2 4.2L19 7" />,
  heart: <path d="M12 21C5 16 2 12 2 8.5A5 5 0 0 1 12 6a5 5 0 0 1 10 2.5C22 12 19 16 12 21z" />,
  shield: (
    <>
      <path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6l8-3z" />
      <path d="M8.5 12l2.5 2.5 4.5-5" />
    </>
  ),
  bolt: <path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" />,
  person: (
    <>
      <circle cx="12" cy="8" r="4" />
      <path d="M4 21c0-4.4 3.6-7 8-7s8 2.6 8 7" />
    </>
  ),
  eye: (
    <>
      <path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z" />
      <circle cx="12" cy="12" r="3" />
    </>
  ),
  smile: (
    <>
      <circle cx="12" cy="12" r="9" />
      <path d="M8 14c1 1.6 2.4 2.4 4 2.4s3-.8 4-2.4" />
      <path d="M9 9.5h.01M15 9.5h.01" />
    </>
  ),
  users: (
    <>
      <circle cx="9" cy="8" r="3" />
      <path d="M3 20c0-3.3 2.7-5.5 6-5.5s6 2.2 6 5.5" />
      <circle cx="17" cy="9" r="2.5" />
      <path d="M16 14.6c3 .1 5 2 5 5" />
    </>
  ),
  globe: (
    <>
      <circle cx="12" cy="12" r="9" />
      <ellipse cx="12" cy="12" rx="4" ry="9" />
      <path d="M3 12h18" />
    </>
  ),
  star: <path d="M12 2l2.9 6.3 6.9.8-5.1 4.7 1.4 6.8L12 17.3 5.9 20.6l1.4-6.8L2.2 9.1l6.9-.8L12 2z" />,
  book: <path d="M12 7c-2-1.5-5-2-8-2v13c3 0 6 .5 8 2 2-1.5 5-2 8-2V5c-3 0-6 .5-8 2zM12 7v13" />,
  plus: <path d="M12 5v14M5 12h14" />,
  arrow: <path d="M4 12h15M13 6l6 6-6 6" />,
  play: <path d="M8 5l11 7-11 7V5z" fill="currentColor" />,
};

export const Icon: React.FC<{name: keyof typeof P | string; size: number; color: string; sw?: number; draw?: number}> = ({
  name,
  size,
  color,
  sw = 2,
  draw,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    stroke={color}
    strokeWidth={sw}
    strokeLinecap="round"
    strokeLinejoin="round"
    style={{color, display: "block", overflow: "visible"}}
    // `draw` (0..1) reveals the strokes like a pen; used for the check marks
    {...(draw !== undefined ? {pathLength: 1} : {})}
  >
    {draw === undefined ? (
      P[name]
    ) : (
      <g style={{strokeDasharray: 40, strokeDashoffset: 40 * (1 - draw)}}>{P[name]}</g>
    )}
  </svg>
);

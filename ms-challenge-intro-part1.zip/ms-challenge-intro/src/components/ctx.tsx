import {createContext, useContext} from "react";

export type SceneInfo = {from: number; dur: number; last: boolean};
export const SceneCtx = createContext<SceneInfo>({from: 0, dur: 1, last: false});
export const useScene = () => useContext(SceneCtx);

/** Converts an ABSOLUTE frame (from timing.ts) to this scene's local frame. */
export const useAt = () => {
  const {from} = useScene();
  return (abs: number) => Math.max(3, abs - from);
};

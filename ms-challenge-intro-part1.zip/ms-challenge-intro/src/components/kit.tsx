import React, {CSSProperties} from "react";
import {interpolate, Sequence, spring, useCurrentFrame, useVideoConfig} from "remotion";
import {theme} from "../theme";
import {useScene} from "./ctx";

type Spr = {readonly damping: number; readonly stiffness: number; readonly mass: number};
export const clamp = {extrapolateLeft: "clamp", extrapolateRight: "clamp"} as const;

export const useSp = (delay: number, cfg: Spr = theme.spring.smooth) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  return spring({frame: frame - delay, fps, config: cfg});
};

/** Premium entrance: opacity + translate + scale together, never a lone fade. */
export const Entrance: React.FC<{
  delay?: number;
  y?: number;
  x?: number;
  from?: number;
  cfg?: Spr;
  style?: CSSProperties;
  children?: React.ReactNode;
}> = ({delay = 0, y = 40, x = 0, from = 0.94, cfg = theme.spring.smooth, style, children}) => {
  const p = useSp(delay, cfg);
  const o = interpolate(p, [0, 0.55], [0, 1], clamp);
  return (
    <div
      style={{
        opacity: o,
        transform: `translate(${(1 - p) * x}px, ${(1 - p) * y}px) scale(${from + (1 - from) * p})`,
        ...style,
      }}
    >
      {children}
    </div>
  );
};

const Word: React.FC<{w: string; delay: number; color: string}> = ({w, delay, color}) => {
  const p = useSp(delay, theme.spring.snappy);
  return (
    <span
      style={{
        display: "inline-block",
        color,
        opacity: interpolate(p, [0, 0.6], [0, 1], clamp),
        transform: `translateY(${(1 - p) * 34}px) scale(${0.92 + 0.08 * p})`,
      }}
    >
      {w}
    </span>
  );
};

/** Word-by-word stagger. Splits on SPACES only - Bengali conjuncts are never broken. */
export const Words: React.FC<{
  text: string;
  size: number;
  delay?: number;
  per?: number;
  color?: string;
  hi?: string[];
  hiColor?: string;
  align?: "left" | "center";
  weight?: number;
  style?: CSSProperties;
}> = ({text, size, delay = 0, per = 4, color = theme.colors.ink, hi = [] as string[], hiColor = theme.colors.primary, align = "left", weight = theme.weight.hero, style}) => (
  <div
    style={{
      display: "flex",
      flexWrap: "wrap",
      justifyContent: align === "center" ? "center" : "flex-start",
      columnGap: Math.round(size * 0.26),
      rowGap: Math.round(size * 0.04),
      fontFamily: theme.fonts.display,
      fontWeight: weight,
      fontSize: size,
      lineHeight: 1.3,
      color,
      ...style,
    }}
  >
    {text.split(" ").map((w, i) => (
      <Word key={i} w={w} delay={delay + i * per} color={hi.includes(w.replace(/[।,.]/g, "")) ? hiColor : color} />
    ))}
  </div>
);

const PhaseInner: React.FC<{len: number; hold: boolean; children?: React.ReactNode}> = ({len, hold, children}) => {
  const f = useCurrentFrame();
  const t = hold ? 0 : interpolate(f, [len - 9, len - 1], [0, 1], {easing: theme.ease.in, ...clamp});
  return (
    <div style={{position: "absolute", inset: 0, opacity: 1 - t, transform: `translateY(${-30 * t}px)`}}>{children}</div>
  );
};

/** Shows children during [from, to) of the scene (local frames) with a quick animated exit. */
export const TextPhase: React.FC<{from: number; to?: number; children?: React.ReactNode}> = ({from, to, children}) => {
  const {dur} = useScene();
  const end = to ?? dur;
  const len = Math.max(10, end - from);
  return (
    <Sequence from={from} durationInFrames={len}>
      <PhaseInner len={len} hold={to === undefined}>
        {children}
      </PhaseInner>
    </Sequence>
  );
};

export const toBn = (s: string) => s.replace(/[0-9]/g, (d) => "০১২৩৪৫৬৭৮৯"[+d]);

/** Counter roll with Bengali digits. Fixed min-width stops layout jitter while digits change. */
export const Counter: React.FC<{
  to: number;
  delay: number;
  decimals?: number;
  group?: boolean;
  minWidth: number;
  style?: CSSProperties;
}> = ({to, delay, decimals = 0, group = false, minWidth, style}) => {
  const p = useSp(delay, theme.spring.count);
  const v = to * p;
  const s = group ? Math.round(v).toLocaleString("en-US") : v.toFixed(decimals);
  return (
    <span style={{display: "inline-block", minWidth, textAlign: "center", ...style}}>{toBn(s)}</span>
  );
};

/** Line that draws itself across a text chunk (used for the "not just a big YouTuber" strike). */
export const Strike: React.FC<{delay: number; children?: React.ReactNode; color?: string; thickness?: number}> = ({
  delay,
  children,
  color = theme.colors.primary,
  thickness = 9,
}) => {
  const f = useCurrentFrame();
  const w = interpolate(f, [delay, delay + 14], [0, 100], {easing: theme.ease.out, ...clamp});
  return (
    <span style={{position: "relative", display: "inline-block"}}>
      {children}
      <span
        style={{
          position: "absolute",
          left: 0,
          top: "56%",
          height: thickness,
          width: `${w}%`,
          background: color,
          borderRadius: thickness,
          boxShadow: `0 0 24px ${theme.colors.glowRed}`,
        }}
      />
    </span>
  );
};

export const Pill: React.FC<{children?: React.ReactNode; size: number; bg: string; color: string; style?: CSSProperties}> = ({
  children,
  size,
  bg,
  color,
  style,
}) => (
  <div
    style={{
      display: "inline-flex",
      alignItems: "center",
      padding: `${Math.round(size * 0.18)}px ${Math.round(size * 0.55)}px`,
      borderRadius: theme.radius.pill,
      background: bg,
      color,
      fontFamily: theme.fonts.display,
      fontWeight: theme.weight.strong,
      fontSize: size,
      lineHeight: 1.3,
      ...style,
    }}
  >
    {children}
  </div>
);

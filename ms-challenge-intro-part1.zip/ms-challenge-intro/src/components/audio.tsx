import React, {useEffect, useState} from "react";
import {Audio, continueRender, delayRender, getRemotionEnvironment, Sequence, staticFile} from "remotion";
import {theme} from "../theme";
import {FPS, SCENE_DEFS, sceneFrom, wordFrame, cueStart} from "../timing";

/* ------------------------------------------------------------------ voiceover (preview only) */
/** Studio preview plays public/voiceover.mp3 if it exists. */
export const VOICEOVER_IN_PREVIEW = true;
/** Final render does NOT include it by default (SFX-only video). Flip to true to bake it in. */
export const VOICEOVER_IN_RENDER = false;

export const PreviewAudio: React.FC = () => {
  const {isRendering} = getRemotionEnvironment();
  const enabled = isRendering ? VOICEOVER_IN_RENDER : VOICEOVER_IN_PREVIEW;
  const [ok, setOk] = useState(false);
  const [handle] = useState(() => delayRender("voiceover-check"));

  useEffect(() => {
    if (!enabled) {
      setOk(false);
      continueRender(handle);
      return;
    }
    // Studio answers a missing file with index.html (HTTP 200), so also check the content type.
    fetch(staticFile("voiceover.mp3"), {method: "HEAD"})
      .then((r) => {
        const type = r.headers.get("content-type") ?? "";
        setOk(r.ok && !type.includes("text/html"));
      })
      .catch(() => setOk(false))
      .finally(() => continueRender(handle));
  }, [enabled, handle]);

  return ok ? <Audio src={staticFile("voiceover.mp3")} volume={1} /> : null;
};

/* ------------------------------------------------------------------ SFX */
type Sfx = "pop" | "click" | "whoosh" | "chime" | "thud" | "tick";
type Ev = {f: number; s: Sfx; v: number; rate?: number};

const LEAD_SFX = 2; // sound starts 2 frames before the visual lands

// volumes stay in 0.2 - 0.35 so a voiceover is never covered
const ev = (f: number, s: Sfx, v = 0.28, rate = 1): Ev => ({f: f - LEAD_SFX, s, v, rate});

const idx = (id: string) => SCENE_DEFS.findIndex((d) => d.id === id);
const B = (id: string) => sceneFrom(idx(id)); // scene start (absolute)

export const buildEvents = (): Ev[] => {
  const e: Ev[] = [];
  // scene transitions: soft whoosh as each wipe passes (wipe starts 8 frames before the cut)
  for (let i = 1; i < SCENE_DEFS.length; i++) e.push({f: sceneFrom(i) - theme.motion.wipeCutAt, s: "whoosh", v: 0.26, rate: i % 2 ? 1 : 1.06});

  // 1 hook
  e.push(ev(2, "chime", 0.3), ev(wordFrame(1, "আসসালামু") + 4, "pop", 0.26), ev(wordFrame(1, "আমি"), "pop", 0.28, 1.05), ev(wordFrame(1, "এমএস"), "pop", 0.28, 0.95));
  // 2 student
  e.push(ev(wordFrame(2, "Intermediate"), "pop", 0.26), ev(wordFrame(2, "প্রথম"), "click", 0.26), ev(wordFrame(2, "দ্বিতীয়"), "click", 0.28, 1.06));
  e.push(ev(wordFrame(3, "পড়াশোনার"), "pop", 0.26), ev(wordFrame(3, "কাজ"), "pop", 0.26, 1.06), ev(wordFrame(3, "স্বপ্ন"), "chime", 0.28, 1.1));
  // 3 dream
  e.push(ev(wordFrame(4, "কিন্তু"), "thud", 0.24), ev(wordFrame(4, "গণ্ডি"), "click", 0.26), ev(wordFrame(4, "পেরিয়ে"), "whoosh", 0.22, 1.1), ev(wordFrame(5, "এমএস"), "chime", 0.3, 0.95));
  // 4 world
  e.push(ev(cueStart(6), "pop", 0.26), ev(wordFrame(6, "YouTube"), "chime", 0.32));
  // 5 numbers
  e.push(ev(wordFrame(7, "প্রায়"), "pop", 0.28), ev(wordFrame(7, "ছয়"), "pop", 0.28, 1.06), ev(wordFrame(8, "শুধু"), "thud", 0.26));
  // 6 love
  e.push(ev(wordFrame(9, "ভালোবাসা"), "pop", 0.26), ev(wordFrame(9, "বিশ্বাস"), "pop", 0.26, 1.06), ev(wordFrame(9, "অক্লান্ত"), "pop", 0.26, 1.12));
  // 7 platforms
  e.push(ev(cueStart(10), "chime", 0.28), ev(wordFrame(10, "Facebook"), "pop", 0.26), ev(wordFrame(10, "TikTok"), "pop", 0.26, 1.06), ev(wordFrame(10, "Instagram"), "pop", 0.26, 1.12));
  // 8 humanity
  e.push(ev(wordFrame(12, "নয়"), "thud", 0.24), ev(wordFrame(12, "মুখে"), "click", 0.26), ev(wordFrame(13, "পাশে"), "click", 0.26, 1.05), ev(wordFrame(13, "মানবতার"), "click", 0.26, 1.1));
  // 9 strength
  e.push(ev(cueStart(14), "chime", 0.28), ev(wordFrame(14, "সবচেয়ে"), "thud", 0.28));
  return e.map((x) => ({...x, f: Math.max(0, x.f)}));
};

export const SfxLayer: React.FC = () => (
  <>
    {buildEvents().map((x, i) => (
      <Sequence key={i} from={x.f} durationInFrames={Math.ceil(0.9 * FPS)}>
        <Audio src={staticFile(`sfx/${x.s}.wav`)} volume={x.v} playbackRate={x.rate ?? 1} />
      </Sequence>
    ))}
  </>
);

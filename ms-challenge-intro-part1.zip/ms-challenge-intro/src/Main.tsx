import React from "react";
import {AbsoluteFill, Sequence} from "remotion";
import {theme} from "./theme";
import {SCENE_DEFS, sceneDur, sceneFrom} from "./timing";
import {SceneCtx} from "./components/ctx";
import {Grade, Grain, Vignette, Wipe} from "./components/layers";
import {PreviewAudio, SfxLayer} from "./components/audio";
import {S1Hook} from "./scenes/S1Hook";
import {S2Student} from "./scenes/S2Student";
import {S3Dream} from "./scenes/S3Dream";
import {S4World} from "./scenes/S4World";
import {S5Numbers} from "./scenes/S5Numbers";
import {S6Love} from "./scenes/S6Love";
import {S7Platforms} from "./scenes/S7Platforms";
import {S8Humanity} from "./scenes/S8Humanity";
import {S9Strength} from "./scenes/S9Strength";

const SCENES: Record<string, React.FC> = {
  hook: S1Hook,
  student: S2Student,
  dream: S3Dream,
  world: S4World,
  numbers: S5Numbers,
  love: S6Love,
  platforms: S7Platforms,
  humanity: S8Humanity,
  strength: S9Strength,
};

export const Main: React.FC = () => (
  <AbsoluteFill style={{background: theme.colors.bg}}>
    {/* layers 1-3: background + assets + graphics live inside each scene */}
    {SCENE_DEFS.map((d, i) => {
      const Comp = SCENES[d.id];
      const from = sceneFrom(i);
      const dur = sceneDur(i);
      return (
        <Sequence key={d.id} from={from} durationInFrames={dur}>
          <SceneCtx.Provider value={{from, dur, last: i === SCENE_DEFS.length - 1}}>
            <Comp />
          </SceneCtx.Provider>
        </Sequence>
      );
    })}

    {/* layers 4-5: grade, grain, vignette over everything */}
    <Grade />
    <Grain />
    <Vignette />

    {/* transitions: wipe is centred on each scene cut */}
    {SCENE_DEFS.slice(1).map((d, i) => (
      <Sequence key={`w-${d.id}`} from={sceneFrom(i + 1) - theme.motion.wipeCutAt} durationInFrames={theme.motion.wipeFrames}>
        <Wipe />
      </Sequence>
    ))}

    <SfxLayer />
    <PreviewAudio />
  </AbsoluteFill>
);

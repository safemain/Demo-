// theme.ts - single source of truth. No inline colours / easings / spring configs in components.
// Palette is taken from the MS Challenge logo (blue + red halves) on a clean, light ground.
import {Easing} from "remotion";

export const theme = {
  colors: {
    bg: "#F6F7FB",
    surface: "#FFFFFF",
    ink: "#10131F",
    dim: "#5B6275",
    primary: "#E8313F", // THE hero colour (logo red) - used sparingly
    blue: "#2B6BFF", // logo blue - structure / secondary
    blueSoft: "#E4ECFF",
    redSoft: "#FFE6E8",
    ytCard: "#F2F2F2", // exact background of the official YouTube logo file, so it blends in
    line: "rgba(16,19,31,0.12)",
    glowRed: "rgba(232,49,63,0.38)",
    glowBlue: "rgba(43,107,255,0.34)",
    onDark: "#FFFFFF",
  },
  fonts: {
    display: '"Hind Siliguri", "Noto Sans Bengali", "Kohinoor Bangla", "Nirmala UI", sans-serif',
  },
  weight: {body: 500, strong: 600, hero: 700},
  radius: {card: 36, pill: 999, tile: 24},
  shadow: {
    card: "0 36px 70px -28px rgba(16,19,31,0.30), 0 8px 18px -10px rgba(16,19,31,0.14)",
    soft: "0 18px 40px -22px rgba(16,19,31,0.28)",
    pop: "0 24px 50px -20px rgba(43,107,255,0.45)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1), // entrances
    inOut: Easing.bezier(0.83, 0, 0.17, 1), // moves
    in: Easing.bezier(0.7, 0, 0.84, 0), // exits only
  },
  spring: {
    snappy: {damping: 14, stiffness: 160, mass: 0.6},
    smooth: {damping: 20, stiffness: 90, mass: 1},
    bouncy: {damping: 11, stiffness: 170, mass: 0.7},
    count: {damping: 30, stiffness: 60, mass: 1},
  },
  motion: {
    exitFrames: 10, // exits are faster than entrances
    wipeFrames: 21, // enter 7 + hold 4 + exit 7, second panel 3 frames behind
    wipeCutAt: 10, // the scene cut happens this many frames into the wipe
    lead: 5, // visuals enter ~5 frames BEFORE the spoken word
  },
} as const;

// All timing derives from the SRT (src/cues.ts, generated). Nothing is hand-placed in seconds.
import {cues} from "./cues";
import {theme} from "./theme";

export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

/** Part 1 covers cues 1..PART_LAST_CUE. For Part 2 raise this and add scenes. */
export const PART_LAST_CUE = 14;

const toFrame = (sec: number) => Math.round(sec * FPS);
export const cueStart = (n: number) => toFrame(cues[n - 1].start);
export const cueEnd = (n: number) => toFrame(cues[n - 1].end);

/**
 * Absolute frame at which a spoken word/phrase of cue `n` starts, estimated from the
 * phrase's character position inside the cue's time window, minus the visual lead.
 * (The SRT has cue-level timing only, so this is the best SRT-derived estimate.)
 */
export const wordFrame = (n: number, phrase: string): number => {
  const c = cues[n - 1];
  const i = c.text.indexOf(phrase);
  if (i < 0) throw new Error(`phrase "${phrase}" not found in cue ${n}: "${c.text}"`);
  return toFrame(c.start + (i / c.text.length) * (c.end - c.start)) - theme.motion.lead;
};

export const TOTAL_FRAMES = cueEnd(PART_LAST_CUE);

export type SceneDef = {id: string; firstCue: number; lastCue: number};

export const SCENE_DEFS: SceneDef[] = [
  {id: "hook", firstCue: 1, lastCue: 1},
  {id: "student", firstCue: 2, lastCue: 3},
  {id: "dream", firstCue: 4, lastCue: 5},
  {id: "world", firstCue: 6, lastCue: 6},
  {id: "numbers", firstCue: 7, lastCue: 8},
  {id: "love", firstCue: 9, lastCue: 9},
  {id: "platforms", firstCue: 10, lastCue: 11},
  {id: "humanity", firstCue: 12, lastCue: 13},
  {id: "strength", firstCue: 14, lastCue: 14},
];

/** Scene boundaries sit on cue boundaries (minus the lead so visuals arrive just before speech). */
export const sceneFrom = (i: number) => (i === 0 ? 0 : cueStart(SCENE_DEFS[i].firstCue) - theme.motion.lead);
export const sceneDur = (i: number) =>
  (i === SCENE_DEFS.length - 1 ? TOTAL_FRAMES : sceneFrom(i + 1)) - sceneFrom(i);

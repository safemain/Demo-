// Hind Siliguri (proper Bengali conjuncts). Loaded through @remotion/google-fonts, which
// downloads once and caches inside the project's bundle on first use - no system font needed.
import {loadFont} from "@remotion/google-fonts/HindSiliguri";

export const {fontFamily, waitUntilDone} = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin", "latin-ext"],
});

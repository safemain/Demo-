# MS Challenge – চ্যানেল ইন্ট্রো (পার্ট ১)

SRT-এর Cue 1–14 (০০:০০ → ১:১৪.৭৬, ২২৪৩ ফ্রেম, ১৯২০×১০৮০, ৩০fps)। কম্পোজিশন ID: `Main`, entry: `src/index.ts`।

```bash
npm install                                          # একবারই
npx remotion studio                                  # প্রিভিউ
npx remotion render src/index.ts Main out/video.mp4  # MP4 রেন্ডার
```

## ফোল্ডার
- `public/logos/` – আপনার দেওয়া YouTube ও MS Challenge লোগো (বিকৃতি ছাড়া)
- `public/sfx/` – ৬টি সিনথেসাইজড SFX (`npm run sfx` দিয়ে আবার বানানো যায়)
- `public/script.srt` – একমাত্র সময়-নির্দেশক; বদলালে `npm run cues` চালান
- `public/voiceover.mp3` – (ঐচ্ছিক) রাখলে Studio প্রিভিউতে বাজবে। রেন্ডারে বন্ধ; চালু করতে `src/components/audio.tsx`-এ `VOICEOVER_IN_RENDER = true`
- `src/theme.ts` – সব রং, ইজিং, spring, ফন্ট
- `src/timing.ts` – SRT থেকে ফ্রেম হিসাব; `SCENE_DEFS` সিনের তালিকা

## পার্ট ২ জোড়া
`src/timing.ts`-এ `PART_LAST_CUE` বাড়িয়ে `SCENE_DEFS`-এ নতুন সিন যোগ করুন, তারপর `Main.tsx`-এর `SCENES`-এ কম্পোনেন্ট বসান।

## ফন্ট
Hind Siliguri, `@remotion/google-fonts` দিয়ে লোড হয়। প্রথমবার চালানোর সময় ইন্টারনেট লাগে, পরে ক্যাশ থেকে চলে।
